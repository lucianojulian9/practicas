/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.prueba;

/**
 *
 * @author Luciano Julian
 */
public class Prueba {

    public static void main(String[] args) {
        
        /*Calculadora de Dias */
        
     
        int dias=12;
        int horas;
        int minutos;
        int segundos;
        
        
     horas = (dias * 24);
     
     minutos = (horas * 60);
     
     segundos = (minutos * 60);
     
        
     System.out.println("En "+dias+" dias hay " +segundos+ " segundos ");   
        
  
    }
}
